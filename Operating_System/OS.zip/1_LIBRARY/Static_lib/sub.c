int sub(int a,int b)
{
	int c = a-b;
	return c;
}
