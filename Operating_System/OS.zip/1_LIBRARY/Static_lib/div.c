float div(int a,int b)
{
	float c =(float) a/b;
	return c;

}
