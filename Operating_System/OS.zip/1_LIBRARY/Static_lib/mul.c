int mul(int a,int b)
{
	int c = a*b;
	return c;
}
