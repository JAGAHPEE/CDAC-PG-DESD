#include<stdio.h>
#include"main.h"
int main()
{

	printf("Addition: %d",add(10,20));
	printf("Subtraction: %d",sub(10,20));
	printf("Division: %f",div(2,5));
	printf("Multiplicaiton: %d",mul(10,10));
}
