#include<stdio.h>
#include"./lib/library.h"
int main()
{
	printf("Addition %d",add(10,20));

}
